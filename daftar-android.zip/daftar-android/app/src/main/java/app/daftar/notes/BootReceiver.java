package app.daftar.notes;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Re-registers every saved reminder after the phone restarts or the app is updated. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        Scheduler.ensureChannels(c);
        Scheduler.apply(c, Scheduler.sp(c).getString("json", "[]"), true);
    }
}
