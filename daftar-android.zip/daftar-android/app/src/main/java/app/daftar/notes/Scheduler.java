package app.daftar.notes;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Icon;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.PowerManager;

import org.json.JSONArray;
import org.json.JSONObject;

/** Schedules exact alarms with the Android system and shows the reminder notification. */
public class Scheduler {
    static final String PREFS = "daftar_native";
    static final String[] TONES = {"alarm", "bell", "melody", "siren"};

    static SharedPreferences sp(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    /** Same 31-multiplier hash as the JavaScript side, so ids match on both sides. */
    static int hid(String s) {
        return s.hashCode() & 0x7fffffff;
    }

    static PendingIntent alarmIntent(Context c, int id, String title, String body, String rid) {
        Intent i = new Intent(c, AlarmReceiver.class);
        i.setAction("app.daftar.notes.ALARM." + id);
        i.putExtra("id", id);
        i.putExtra("title", title);
        i.putExtra("body", body);
        i.putExtra("rid", rid);
        return PendingIntent.getBroadcast(c, id, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static void cancelAll(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        String ids = sp(c).getString("ids", "");
        if (!ids.isEmpty()) {
            for (String s : ids.split(",")) {
                try {
                    am.cancel(alarmIntent(c, Integer.parseInt(s), "", "", ""));
                } catch (Exception ignored) { }
            }
        }
        sp(c).edit().putString("ids", "").apply();
    }

    static void setAlarm(Context c, long at, int id, String title, String body, String rid) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        PendingIntent show = PendingIntent.getActivity(c, 0, new Intent(c, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        // setAlarmClock is the most reliable API: it is exempt from Doze and battery restrictions.
        am.setAlarmClock(new AlarmManager.AlarmClockInfo(at, show), alarmIntent(c, id, title, body, rid));
    }

    static void apply(Context c, String json, boolean fireMissed) {
        try {
            cancelAll(c);
            JSONArray a = new JSONArray(json);
            StringBuilder ids = new StringBuilder();
            long now = System.currentTimeMillis();
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                long at = o.getLong("at");
                int id = o.getInt("id");
                String t = o.optString("title");
                String b = o.optString("body");
                String rid = o.optString("rid");
                if (at <= now) {
                    if (fireMissed && now - at < 6L * 3600L * 1000L) show(c, id, t, b, rid);
                    continue;
                }
                setAlarm(c, at, id, t, b, rid);
                ids.append(id).append(",");
            }
            sp(c).edit().putString("ids", ids.toString()).putString("json", json).apply();
        } catch (Exception ignored) { }
    }

    static String channelId(Context c) {
        SharedPreferences p = sp(c);
        String mode = p.getString("mode", "both");
        String tone = p.getString("tone", "alarm");
        if ("mute".equals(mode)) return "r_mute";
        if ("vibe".equals(mode)) return "r_vibe";
        return "r_" + tone + ("ring".equals(mode) ? "_s" : "_sv");
    }

    static void ensureChannels(Context c) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        AudioAttributes aa = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
        long[] vib = new long[]{0, 700, 300, 700, 300, 700, 300, 700};
        for (String t : TONES) {
            int res = c.getResources().getIdentifier("tone_" + t, "raw", c.getPackageName());
            Uri uri = Uri.parse("android.resource://" + c.getPackageName() + "/" + res);
            for (int v = 0; v < 2; v++) {
                String id = "r_" + t + (v == 0 ? "_s" : "_sv");
                NotificationChannel ch = new NotificationChannel(id, "تذكير " + t + (v == 0 ? " (صوت)" : " (صوت واهتزاز)"), NotificationManager.IMPORTANCE_HIGH);
                ch.setSound(uri, aa);
                ch.enableVibration(v == 1);
                if (v == 1) ch.setVibrationPattern(vib);
                ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
                nm.createNotificationChannel(ch);
            }
        }
        NotificationChannel vibOnly = new NotificationChannel("r_vibe", "تذكير (اهتزاز فقط)", NotificationManager.IMPORTANCE_HIGH);
        vibOnly.setSound(null, null);
        vibOnly.enableVibration(true);
        vibOnly.setVibrationPattern(vib);
        nm.createNotificationChannel(vibOnly);
        NotificationChannel mute = new NotificationChannel("r_mute", "تذكير (صامت)", NotificationManager.IMPORTANCE_DEFAULT);
        mute.setSound(null, null);
        mute.enableVibration(false);
        nm.createNotificationChannel(mute);
    }

    static void show(Context c, int id, String title, String body, String rid) {
        ensureChannels(c);
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        String lang = sp(c).getString("lang", "ar");
        boolean en = "en".equals(lang);

        PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
        PowerManager.WakeLock wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "daftar:alarm");
        wl.acquire(8000);

        Intent open = new Intent(c, MainActivity.class);
        open.putExtra("rid", rid);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent po = PendingIntent.getActivity(c, id, open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Notification.Builder b = new Notification.Builder(c, channelId(c))
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(en ? "Time for: " + title : "حان وقت: " + title)
                .setContentText(body)
                .setContentIntent(po)
                .setAutoCancel(true)
                .setCategory(Notification.CATEGORY_REMINDER)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setShowWhen(true)
                .setWhen(System.currentTimeMillis());

        if (!"test".equals(rid)) {
            b.addAction(new Notification.Action.Builder(Icon.createWithResource(c, R.drawable.ic_stat),
                    en ? "Done" : "تم", actionIntent(c, "DONE", id, rid, title, body)).build());
            b.addAction(new Notification.Action.Builder(Icon.createWithResource(c, R.drawable.ic_stat),
                    en ? "Snooze 10 min" : "تأجيل 10 د", actionIntent(c, "SNOOZE", id, rid, title, body)).build());
        }
        Notification n = b.build();
        String mode = sp(c).getString("mode", "both");
        if (!"mute".equals(mode) && !"vibe".equals(mode)) n.flags |= Notification.FLAG_INSISTENT;
        nm.notify(id, n);
    }

    static PendingIntent actionIntent(Context c, String act, int id, String rid, String title, String body) {
        Intent i = new Intent(c, ActionReceiver.class);
        i.setAction("app.daftar.notes." + act + "." + id);
        i.putExtra("act", act);
        i.putExtra("id", id);
        i.putExtra("rid", rid);
        i.putExtra("title", title);
        i.putExtra("body", body);
        return PendingIntent.getBroadcast(c, id + (act.equals("DONE") ? 1 : 2), i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    /** Queue an action from the notification so the web app can apply it next time it opens. */
    static void queueAction(Context c, String rid, String action, long at) {
        try {
            JSONArray a = new JSONArray(sp(c).getString("actions", "[]"));
            JSONObject o = new JSONObject();
            o.put("rid", rid);
            o.put("action", action);
            o.put("at", at);
            a.put(o);
            sp(c).edit().putString("actions", a.toString()).apply();
        } catch (Exception ignored) { }
    }
}
