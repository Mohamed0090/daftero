package app.daftar.notes;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.View;
import android.webkit.JavascriptInterface;

import org.json.JSONObject;

/** Methods the web app can call as window.DaftarNative.* */
public class Bridge {
    private final Activity a;

    Bridge(Activity a) {
        this.a = a;
    }

    @JavascriptInterface
    public String status() {
        try {
            NotificationManager nm = (NotificationManager) a.getSystemService(Context.NOTIFICATION_SERVICE);
            boolean notif = nm.areNotificationsEnabled();
            NotificationChannel ch = nm.getNotificationChannel(Scheduler.channelId(a));
            boolean channel = ch == null || ch.getImportance() != NotificationManager.IMPORTANCE_NONE;
            PowerManager pm = (PowerManager) a.getSystemService(Context.POWER_SERVICE);
            boolean battery = pm.isIgnoringBatteryOptimizations(a.getPackageName());
            JSONObject o = new JSONObject();
            o.put("notif", notif);
            o.put("channel", channel);
            o.put("battery", battery);
            return o.toString();
        } catch (Exception e) {
            return "{\"notif\":true,\"channel\":true,\"battery\":false}";
        }
    }

    @JavascriptInterface
    public void requestNotif() {
        a.runOnUiThread(() -> {
            try {
                NotificationManager nm = (NotificationManager) a.getSystemService(Context.NOTIFICATION_SERVICE);
                if (Build.VERSION.SDK_INT >= 33
                        && a.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                        && !nm.areNotificationsEnabled()) {
                    a.requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
                } else {
                    Intent i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
                    i.putExtra(Settings.EXTRA_APP_PACKAGE, a.getPackageName());
                    a.startActivity(i);
                }
            } catch (Exception ignored) { }
        });
    }

    @JavascriptInterface
    public void openBattery() {
        a.runOnUiThread(() -> {
            try {
                a.startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            } catch (Exception e) {
                try {
                    Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                    i.setData(Uri.parse("package:" + a.getPackageName()));
                    a.startActivity(i);
                } catch (Exception ignored) { }
            }
        });
    }

    @JavascriptInterface
    public void setSchedule(String json) {
        Scheduler.apply(a, json, false);
    }

    @JavascriptInterface
    public void setPrefs(String mode, String tone, String lang) {
        Scheduler.sp(a).edit().putString("mode", mode).putString("tone", tone).putString("lang", lang).apply();
    }

    @JavascriptInterface
    public void testNotify() {
        Scheduler.show(a, 424242, "تجربة التذكير", "هكذا سيظهر تذكيرك ويرنّ", "test");
    }

    @JavascriptInterface
    public String takeActions() {
        String s = Scheduler.sp(a).getString("actions", "[]");
        Scheduler.sp(a).edit().putString("actions", "[]").apply();
        return s;
    }

    @JavascriptInterface
    public String takeOpen() {
        String s = Scheduler.sp(a).getString("openRid", "");
        Scheduler.sp(a).edit().putString("openRid", "").apply();
        return s;
    }

    @JavascriptInterface
    public void copy(String text) {
        ClipboardManager cm = (ClipboardManager) a.getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("daftar", text));
    }

    @JavascriptInterface
    public void share(String text) {
        a.runOnUiThread(() -> {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_TEXT, text);
            a.startActivity(Intent.createChooser(i, null));
        });
    }

    @JavascriptInterface
    public void setBars(boolean dark) {
        a.runOnUiThread(() -> {
            int color = dark ? 0xFF0F1115 : 0xFFF7F3EA;
            a.getWindow().setStatusBarColor(color);
            a.getWindow().setNavigationBarColor(color);
            View d = a.getWindow().getDecorView();
            int flags = d.getSystemUiVisibility();
            int light = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            d.setSystemUiVisibility(dark ? (flags & ~light) : (flags | light));
        });
    }
}
