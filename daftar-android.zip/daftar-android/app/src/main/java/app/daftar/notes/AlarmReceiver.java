package app.daftar.notes;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        Scheduler.show(c, i.getIntExtra("id", 1), i.getStringExtra("title"),
                i.getStringExtra("body"), i.getStringExtra("rid"));
    }
}
