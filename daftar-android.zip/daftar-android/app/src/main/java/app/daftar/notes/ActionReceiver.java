package app.daftar.notes;

import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class ActionReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        String act = i.getStringExtra("act");
        String rid = i.getStringExtra("rid");
        int id = i.getIntExtra("id", 0);
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.cancel(id);
        if ("DONE".equals(act)) {
            Scheduler.queueAction(c, rid, "done", 0);
        } else if ("SNOOZE".equals(act)) {
            long at = System.currentTimeMillis() + 10L * 60L * 1000L;
            // Same id formula as the web app: hash(rid + "|" + at)
            Scheduler.setAlarm(c, at, Scheduler.hid(rid + "|" + at),
                    i.getStringExtra("title"), i.getStringExtra("body"), rid);
            Scheduler.queueAction(c, rid, "snooze", at);
        }
    }
}
